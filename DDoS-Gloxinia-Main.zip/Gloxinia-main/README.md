# DDoS-Gloxinia

# What is a DDoS Attack?
A Distributable Denied-of-Service (DDOS) attack server that cuts off targets or surrounding infrastructure in a flood of Internet traffic

DDoS attacks achieve effectiveness using multiple compromised computer systems as a source of attack traffic. Search engines may include computers and other network resources such as IoT devices.
From a higher level, the DDOS attack is like an unexpected traffic jam stuck on a highway, preventing regular traffic from reaching its destination.

## NOTE (Please, make sure you have installed python 3 )


## For Termux
To use the DGloxinia type the following commands in Termux:

`pkg install git -y`

`pkg install python -y`

`pkg install python3 -y`

`git clone https://github.com/MVPxGloxinia/DDoS-Gloxinia.git`

`cd DDoS-Gloxinia`

`$ ls`

`$ python3 DGloxinia.py` 

## USGAE
`python3 DGloxinia.py -s [ip Address] -t 135`

`example: python3 DGloxinia.py -s 0.00.00.00 -t 135`

## For Debian-based GNU/Linux distributions
To use the application, type in the following commands in GNU/Linux terminal.

`sudo apt install git`
`git clone https://github.com/MVPxGloxinia/DDoS-Gloxinia.git`
`cd DDoS-Gloxinia`
`$ ls`
`$ python3 DGloxinia.py` OR `python2 DGloxinia.py`

## For Windows

`git clone https://github.com/MVPxGloxinia/DDoS-Gloxinia`

`cd DDoS-Gloxinia`

` ls`

`python3 DGloxinia.py` OR `python DGloxinia.py`

`python3 DGloxinia.py -s [ip Address] -t 135`

`example: python3 DGloxinia.py -s 0.00.00.00 -t 135`

## For MacOS

Install Brew and Install dependencies (python 3)

# Note:
If you find any problems than please write on issue github and to our Telegram Group. Don't use for revenge! Make sure your anonymity!
It's made for just testing purpose.
We are not responsible for any abuse or damage caused by this program. Only for Educational Purpose.
Thanks.
 
## Requirments ▶

●🖥Linux OS( Kali 🐉 Ubuntu )

●📱Termux >

●🖥Windows

●🖥MAC

# Modified by @MVPxGloxinia

